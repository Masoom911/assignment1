const displayedImage = document.querySelector('.displayed-img');
const thumbBar = document.querySelector('.thumb-bar');

const btn = document.querySelector('button');
const overlay = document.querySelector('.overlay');

/* Declaring the array of image filenames */
const imgArr = ["pic1.jpg","pic2.jpg","pic3.jpg","pic4.jpg","pic5.jpg"];
/* Declaring the alternative text for each image file */
const imgAlts = [
        {"pic1": "Blue human eye picture"},
        {"pic2": "A rock thats shaped as a wave"},
        {"pic3": "Purple and white pansis"},
        {"pic4": "A section of a wall thats from a pharoah's tomb"},
        {"pic5": "A closeup of a moth thats on a leaf"}
];
/* Looping through images */
for (let i = 0; i < imgArr.length; i++) {
const newImage = document.createElement('img');
newImage.setAttribute('src', xxx);
newImage.setAttribute('alt', xxx);
thumbBar.appendChild(newImage);
}
/* Wiring up the Darken/Lighten button */
btn.addEventListener("click", () => {
    if (btn.getAttribute("class") == "dark") {
        btn.textContent = "Lighten";
        overlay.computedStyleMap.backgroundColor = "rgb(0 0 0 / 0%)";
    }
})

thumbBar.addEventListener("click", (event) => {
    displayedImage.setAttribute('src', event.target.getAttribute('src'));
    displayedImage.setAttribute('alt', event.target.getAttribute('src'));

});