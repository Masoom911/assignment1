// <!--
// Name: Masoom
// File: bouncing balls part 4.js
// Date: wednesday February 26
// bouncing balls
// -->

// setup canvas
const canvas = document.querySelector("canvas");
// const ctx canvas get context 2d
const ctx = canvas.getContext("2d");

// const width canvas width window innerwidth
const width = (canvas.width = window.innerWidth);
// const height canvas height window inner height
const height = (canvas.height = window.innerHeight);

// function to generate random number
function random(min, max) {
  // returns math.floor Math random * max - min + 1 + min
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// function to generate random color
function randomRGB() {
  // return rgb random 0 255 random 0 255 random 0 255
  return `rgb(${random(0, 255)},${random(0, 255)},${random(0, 255)})`;
}

// class shape 
class shape {
  // constructor x,y,velx,vely
    constructor(x, y, velX, velY) {
      // this x = x;
      this.x = x;
      // this.y = y
      this.y = y;
      // this.velX=velX
      this.velX = velX;
      // this.velY=velY
      this.velY = velY;
    }
}
// class Ball extends shape 
    class Ball extends shape
    {
      // constructor
        constructor(x, y, velX, velY, color, size) {
          // superx,y,velx,velY
        super(x,y,velX,velY)
        // this.color=color
        this.color = color;
        // this size = size
        this.size = size;
        // this exists=true
        this.exists=true
        }
         // draw
    draw() { 
      // beginpath
        ctx.beginPath();
        // ctx fillstyle = this.color
        ctx.fillStyle = this.color;
        // ctx.arc this.x this.y this.size 0 2 * math PI
        ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
        // ctx.fill
        ctx.fill();
     
      }
      // update
      update() {
        // if thisx + this size > = width
        if ((this.x + this.size) >= width) {
          // this.velX = - this.velX
          this.velX = -(this.velX);
        }
      // if this.x - this.size <= 0
        if ((this.x - this.size) <= 0) {
          // this.velX = - this.velX
          this.velX = -(this.velX);
        }
      // if this.y + this.size >= height
        if ((this.y + this.size) >= height) {
          // this.velY = - this.velY
          this.velY = -(this.velY);
        }
      // if this.y - this.size <=0
        if ((this.y - this.size) <= 0) {
          // this.velY = - this. velY
          this.velY = -(this.velY);
        }
      // this x = this velX
        this.x += this.velX;
        // this.y += this.velY
        this.y += this.velY;
      }
      // collisionDetect
      collisionDetect() {
        // for const ball of balls
        for (const ball of balls) {
          // this === ball && ball exists
          if (!(this === ball) && ball.exists) {
            // const dx thisx - ball x
            const dx = this.x - ball.x;
            // const dy = thix y - ball.y
            const dy = this.y - ball.y;
            // distance math sqrt
            const distance = Math.sqrt(dx * dx + dy * dy);
      // distance size ball size
            if (distance < this.size + ball.size) {
              // ball color
              ball.color = this.color = randomRGB();
            }
          }
        }
      }      
  }
  // class evilcircle extends shape
  class evilcircle extends shape{
    // constructor x,y
    constructor(x,y) {
      // super x,y,20,20
        super(x,y,20,20)
        // this.color=white
        this.color="white"  
        // this.size=10
        this.size=10
        // window.addEventListener keydown e =>
        window.addEventListener("keydown", (e) => {
          // switch e key
            switch (e.key) {
              // case a
              case "a":
                // this.x -= this.velX
                this.x -= this.velX;
                // break
                break;
                // case d
              case "d":
                // this.x += this.velX
                this.x += this.velX;
                // break
                break;
                // case w
              case "w":
                // this y -= this velY
                this.y -= this.velY;
                // break
                break;
                // case s
              case "s":
                // this y += this velY
                this.y += this.velY;
                // Break
                break;
            }
          });          
    } 
    // Draw beginPath
    draw() { 
      // ctx beginpath
        ctx.beginPath();
        // ctx strokesytle this color 
        ctx.strokeStyle = this.color;
        // ctx arc this x thisy this size 0, 2 * MathPI
        ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
        // ctx stroke
        ctx.stroke();
        // ctx line width = 3
        ctx.lineWidth= 3; 
      }
      // checkBounds
      checkBounds() {
        // if this x + this size >= width
        if ((this.x + this.size) >= width) {
          // this x this size
          this.x = this.size;
        }
      // if this x - this size <= 0
        if ((this.x - this.size) <= 0) {
          // this x = this size
          this.x = this.size;
        }
       // if this y + this size >= height
        if ((this.y + this.size) >= height) {
          // this y this size
          this.y = this.size;
        }
      // if this y - this size <= 0
        if ((this.y - this.size) <= 0) {
          // this y this size
          this.y = this.size;
        }
      
      }
      // collisionDetect
      collisionDetect() {
        // for const ball of balls 
        for (const ball of balls) {
          // if ball.exists
          if (ball.exists) {
            // const dx = this x - ball x 
            const dx = this.x - ball.x;
            // const dy = this y - ball y 
            const dy = this.y - ball.y;
            // const distance = math sqrt dx*dx+dy*dy
            const distance = Math.sqrt(dx * dx + dy * dy);
            // if distance < this size + ball size
            if (distance < this.size + ball.size) {
              // ball exists = false
            ball.exists=false;
            // ballcount--
            ballcount--;
            // ballcountdisplay . textContent = ball count ballcount
            ballcountdisplay.textContent = `Ball count: ${ballcount}`;
            }
          }
        }
}      
}
// constant balls 
  const balls = [];
  // const testball new Ball 50,100,4,4 blue,10
  const testBall = new Ball(50, 100, 4, 4, "blue", 10);
  // testball x 
  testBall.x;
  // testball size
  testBall.size;
  // testball color
  testBall.color;
  // testBall draw
  testBall.draw();
  // let ballbount go up to 25
  let ballcount = 25;
  // const ballcountdisplay = document get element by id ballcount
  const ballcountdisplay = document.getElementById("ballcount")  
  // While balls.length < 25 
while (balls.length < 25) {
  // const size random 10, 20
  const size = random(10, 20);
  // const ball new ball
  const ball = new Ball(
    // ball position always drawn at least one ball width
    // away from the edge of the canvas, to avoid drawing errors
    random(0 + size, width - size),
    // random 0 + size height - size
    random(0 + size, height - size),
    // random -7 7
    random(-7, 7),
    // random -7,7
    random(-7, 7),
    // randomRGB
    randomRGB(),
    // size
    size,
  );
// balls push
  balls.push(ball);
}
// const evil = new evilcircle random 0 width random 0 height
const evil = new evilcircle (random(0,width),random(0,height))
  // loop
function loop() {
  // ctx fillstyle = rgb  0 0 0 / 25%
    ctx.fillStyle = "rgb(0 0 0 / 25%)";
    // ctx fillrect 0,0, width, height
    ctx.fillRect(0, 0, width, height);
  // for const ball of balls 
    for (const ball of balls) {
        // ball.exists
        if (ball.exists) {
          // ball draw
            ball.draw();
            // ball update
            ball.update();
            // ball collisiondetect
            ball.collisionDetect();
        }
    }
// calls the methon in the evil circle
    evilcircle.draw();
    // evilcircle collisiondetect
    evilcircle.collisionDetect();
    // evilcirle.checkbounds
    evilcircle.checkBounds();

  // requestAnimationFrame
    requestAnimationFrame(loop);
    // loop
  }
  loop();


  
  

  