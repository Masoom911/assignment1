// <!--
// Name: Masoom
// File: javascript part 3.js
// Date: wednesday February 26
// bouncing balls
// -->

// setup canvas
const canvas = document.querySelector("canvas");
// const ctx = canvas get context 2d
const ctx = canvas.getContext("2d");

// const width = canvas width = window innerwidth
const width = (canvas.width = window.innerWidth);
// const height = canvas height window innerheight
const height = (canvas.height = window.innerHeight);

// function to generate random number
function random(min, max) {
  // returns math floor math random * max - min + 1 + min
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// function to generate random color
function randomRGB() {
  // return rgb rnadom 0, 255 random 0 255 random 0 255
  return `rgb(${random(0, 255)},${random(0, 255)},${random(0, 255)})`;
}

// class ball 
class Ball {
  // constructor x,y, velX, velY, color, size
    constructor(x, y, velX, velY, color, size) {
      // this x = x
      this.x = x;
      // this y = y
      this.y = y;
      // this velX = velX
      this.velX = velX;
      // this velY = velY
      this.velY = velY;
      // this color = color
      this.color = color;
      // this size = size
      this.size = size;
    }
         // draw
    draw() { 
      // ctx beginpath 
        ctx.beginPath();
        // ctx fillstyle = this color
        ctx.fillStyle = this.color;
        // ctx arc thisx, this y, this size, 0,2 * math.PI
        ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
        // ctx fill
        ctx.fill();
     
      }
      // update 
      update() {
        // if this x + this size >= width 
        if ((this.x + this.size) >= width) {
          // this velX =- this velX
          this.velX = -(this.velX);
        }
      // if this x - this size <= 0 
        if ((this.x - this.size) <= 0) {
          // this velX = - this velX
          this.velX = -(this.velX);
        }
      // if this y + this size >= height
        if ((this.y + this.size) >= height) {
          // this velY = - this velY
          this.velY = -(this.velY);
        }
      // if this y - this size <= 0 
        if ((this.y - this.size) <= 0) {
          // this velY = - this velY
          this.velY = -(this.velY);
        }
      // this x += this velX
        this.x += this.velX;
        // this y += this velY
        this.y += this.velY;
      }
      // collisionDetect
      collisionDetect() {
        // for const ball of balls
        for (const ball of balls) {
          // if this !== ball
          if (this !== ball) {
            // const dx = thos x - ballx
            const dx = this.x - ball.x;
            // const dy = this y - bally
            const dy = this.y - ball.y;
            // const distance =  math sqrt dx * dx + dy * dy
            const distance = Math.sqrt(dx * dx + dy * dy);
      // if distance < this size + size + ball size 
            if (distance < this.size + ball.size) {
              // ball solor = this color = randomRGB
              ball.color = this.color = randomRGB();
            }
          }
        }
      }      
  }
  // const balls 
  const balls = [];
  // const testBall new ball 50,100,4,4, blue,10
  const testBall = new Ball(50, 100, 4, 4, "blue", 10);
  // testball x 
  testBall.x;
  // testball size 
  testBall.size;
  // testball color 
  testBall.color;
  // testball draw
  testBall.draw();   
  // while balls length < 25
while (balls.length < 25) {
  // const size = random 10, 20 
  const size = random(10, 20);
  // const ball new ball
  const ball = new Ball(
    // ball position always drawn at least one ball width
    // away from the edge of the canvas, to avoid drawing errors
    random(0 + size, width - size),
    // random 0 _ size, height - size
    random(0 + size, height - size),
    // random -7, 7
    random(-7, 7),
    // random -7, 7
    random(-7, 7),
    // randomRGB
    randomRGB(),
    // size
    size,
  );
// balls push ball
  balls.push(ball);
}
// function loop
  function loop() {
    // ctx fillstyle rgb 0 0 0 / 25%
    ctx.fillStyle = "rgb(0 0 0 / 25%)";
    // ctx fillRec 0, 0, width, height 
    ctx.fillRect(0, 0, width, height);
  
    // for const ball of balls 
    for (const ball of balls) {
      // ball daw 
      ball.draw();
      // ball update 
      ball.update();
      // ball collisiondetect
      ball.collisionDetect();
    }
  // requestAnimationFrame loop
    requestAnimationFrame(loop);
    // loop
  }
  loop();
  
  

  