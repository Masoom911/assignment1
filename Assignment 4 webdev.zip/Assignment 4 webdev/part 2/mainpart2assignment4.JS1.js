/* // <!--
    // Name: Masoom Yosofi
    // File: style.css
    // Date: wednesday February 26
    // image generator */
    
    // displaying the image
const displayedImage = document.querySelector('.displayed-img');
// const thumb bar docmunet quryselector thumbbar
const thumbBar = document.querySelector('.thumb-bar');
// selects the query
const btn = document.querySelector('button');
// const overlay document queryselctor
const overlay = document.querySelector('.overlay');

/* Declaring the array of image filenames */
const imgArr = ["pic1.jpg","pic2.jpg","pic3.jpg","pic4.jpg","pic5.jpg"];

/* Declaring the alternative text for each image file */
const imgAlts = [
    {"pic1": "A blue human eye"},
    {"pic2": "A Rock the shape of a wave"}, 
    {"pic3": "purple and white pansies"}, 
    {"pic4": "A part of a wall from pharoah's tomb"}, 
    {"pic5": "A moth on a leaf"}
];
/* Looping through images */
for (let i = 1; i < 6; i++) {
  // const newImage document createElement img
  const newImage = document.createElement('img');
  // newimage setattribute src image / pic
  newImage.setAttribute('src', `images/pic${i}.jpg`);
  // new image setAttribute 
  newImage.setAttribute('alt', imgAlts[i-1]);
  // tumbBar appendChild
  thumbBar.appendChild(newImage);
}



/* Wiring up the Darken/Lighten button */
btn.addEventListener("click", () => {
  // if btn get Attribute class dark
  if (btn.getAttribute("class") === "dark") {
    // btn setAttribute class light
      btn.setAttribute("class", "light");
      // btn textContent lighten
      btn.textContent = "Lighten";
      // overlay Style background color = rgb 0 0 0 / 50%
      overlay.style.backgroundColor = "rgb(0 0 0 / 50%)";
      // else
  } else {
    // btn set attribute class dark
      btn.setAttribute("class", "dark");
      // btn textcontent darken
      btn.textContent = "Darken";
      // overlay style backgroundcolor = rgb 0 0 0/ 0%
      overlay.style.backgroundColor = "rgb(0 0 0 / 0%)";
  }
});

/* Add a click event listener to each thumbnail */
  thumbBar.addEventListener("click", (event) => {
    // displayedImage setAttribute src event terget get attribute
    displayedImage.setAttribute('src', event.target.getAttribute('src'));
    // displayedimage set attribute alr event target getArrtibute 
    displayedImage.setAttribute('alt', event.target.getAttribute('alt'));
});