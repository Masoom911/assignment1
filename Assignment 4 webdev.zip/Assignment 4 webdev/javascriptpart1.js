 //* 
/// Name: Masoom
/// File: part 1 html.html
/// Date: wednesday February 26
/// Generating a short story using Html and java script
/*** */
// customName document getElementById
const customName = document.getElementById('customname');
// randomize the document queryselector
const randomize = document.querySelector('.randomize');
// story document queryselector
const story = document.querySelector('.story');

// fuction randomValuefromthearray
function randomValueFromArray(array){
  // constant random = math floor math random * array.length
  const random = Math.floor(Math.random()*array.length);
  // returns array random
  return array[random];
}
// the story
const storyText = "It was 94 fahrenheit outside, so :insertx: went for a walk. When they got to :inserty:, they stared in horror for a few moments, then :insertz:. Bob saw the whole thing, but was not surprised — :insertx: weighs 300 pounds, and it was a hot day.";
// Willy the Goblin", "Big Daddy", "Father Christmas
const insertX = ["Willy the Goblin", "Big Daddy", "Father Christmas"];
// the soup kitchen", "Disneyland", "the White House
const insertY = ["the soup kitchen", "Disneyland", "the White House"];
// spontaneously combusted", "melted into a puddle on the sidewalk", "turned into a slug and crawled away
const insertZ = ["spontaneously combusted", "melted into a puddle on the sidewalk", "turned into a slug and crawled away"];

// randomize add event listener
randomize.addEventListener('click', result);

function result() {
    let newStory = storyText;
// const randomvaluefromarray
    const xItem = randomValueFromArray(insertX);
    // const randomvaluefromarray
    const yItem = randomValueFromArray(insertY);
    // const randomvaluefromarray
    const zItem = randomValueFromArray(insertZ);
// newstory = newstory
    newStory = newStory
    // replaceAll(":insertx
                .replaceAll(":insertx:", xItem)
                // replace
                .replace(":inserty:", yItem)
                // replace
                .replace(":insertz:",zItem);

//   if(customName.value !== '') {
  if(customName.value !== '') {
    // constant name = customname value
    const name = customName.value;
    // new story = new sotry replaces bob with the name
    newStory = newStory.replace("Bob", name);
  }
// if the document getselementbyid uk checked
  if(document.getElementById("uk").checked) {
    // constant weight = math.rounds 300 / 14 stone
    const weight = `${Math.round(300 / 14)} stone`;
    // constant temperature = math round 94 - 32 * 5/9 cenigrade
    const temperature =  `${Math.round((94 - 32) * (5/9))} centigrade`;
    // newstory = newsotry
    newStory = newStory
    // replace with300 pounds and weight
                .replace("300 pounds", weight)
                // replace with 94 fahrenheit and temprature
                .replace("94 fahrenheit", temperature);

  }
// store textcontent newstiry
  story.textContent = newStory;
  // story style visibility = visible
  story.style.visibility = 'visible';
}
